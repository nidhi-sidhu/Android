package com.jk.sirra;

import android.content.Intent;
import android.provider.ContactsContract;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.Toast;

public class LoginActivity extends AppCompatActivity implements View.OnClickListener
{
    EditText e1,e2;
    Button b1,b2;

    @Override
    protected void onCreate(Bundle savedInstanceState)
    {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_login);

        b1 =  findViewById(R.id.btnLogin);
        b2 =  findViewById(R.id.btnRegister);
        e1 =  findViewById(R.id.edtEmail);
        e2 =  findViewById(R.id.edtPassword);

        b1.setOnClickListener(this);
        b2.setOnClickListener(this);
    }

    @Override
    public void onClick(View v)
    {
        if(v == b1)
        {
            String email = e1.getText().toString();
            String pass = e2.getText().toString();

            if(email.equals("test") && pass.equals("test"))
            {
                Toast.makeText(this,"Login successfully",Toast.LENGTH_SHORT).show();
            }
            else
            {
                Toast.makeText(this,"Invalid Username and password",Toast.LENGTH_SHORT).show();
            }

            Toast.makeText(this, "login clicked", Toast.LENGTH_SHORT).show();
        }
        else if(v == b2)
        {
            Toast.makeText(this,"Register clicked",Toast.LENGTH_SHORT).show();

            Intent registerIntent = new Intent(this,RegisterActivity.class);
            startActivity(registerIntent);

        }




    }
}
